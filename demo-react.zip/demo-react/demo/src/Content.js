import React from "react";

const Content = () => {
  function randomName() {
    const names = ["john", "peter"];
    const i = Math.floor(Math.random() * 2);
    return names[i];
  }

  const addItem = () => console.log("Item Added");
  const addItem1 = (name) => console.log(name);

  return (
    <main>
      <p>Logged in by {randomName()}</p>
      {/* <button onClick={addItem()}>Add</button> */}
      <button onClick={addItem}>Add</button>
      {/* <button onClick={addItem1("john")}>Add</button> */}
      {/* <button onClick={() => addItem1("john")}>Add</button> */}
      {/* <button onClick={(e) => addItem1(e)}>Add</button> */}
    </main>
  );
};

export default Content;
