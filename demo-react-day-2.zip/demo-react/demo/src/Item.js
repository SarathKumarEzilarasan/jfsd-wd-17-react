import React from "react";

const Item = ({ item, handleCheck, deleteTask }) => {
  return (
    <li className="item">
      <input
        type="checkbox"
        checked={item.checked}
        onChange={() => handleCheck(item.id)}
      ></input>
      <label style={item.checked ? { textDecoration: "line-through" } : null}>
        {item.description}
      </label>
      <button onClick={() => deleteTask(item.id)}>Delete</button>
    </li>
  );
};

export default Item;
