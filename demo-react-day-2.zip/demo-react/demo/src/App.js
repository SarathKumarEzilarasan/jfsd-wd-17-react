import { useState, useRef } from "react";
import "./App.css";
import Content from "./Content";
import Footer from "./Footer";
import Header from "./Header";
import AddItem from "./AddItem";
import SearchItem from "./SearchItem";

function App() {
  // const name = "demo";
  // const name = { a: 1, b: 2 };
  // const [items, setItems] = useState([
  //   { id: 1, checked: true, description: "Practice Java" },
  //   { id: 2, checked: false, description: "Practice JavaScript" },
  //   { id: 3, checked: false, description: "Practice Database" },
  // ]);
  const [items, setItems] = useState(
    JSON.parse(localStorage.getItem("todo_list"))
  );

  const handleCheck = (id) => {
    const listItems = items.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(listItems);
  };

  const deleteTask = (id) => {
    const listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const [newItem, setNewItem] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
    addItem(newItem);
    setNewItem("");
  };

  const addItem = (i) => {
    const id = items.length ? items[items.length - 1].id + 1 : 1;
    const addNewItem = {
      id: id,
      checked: false,
      description: i,
    };
    const listItems = [...items, addNewItem];
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const [searchItem, setSearchItem] = useState("");
  const inputRef = useRef();

  return (
    <div className="App">
      <Header title="Demo App" />
      <AddItem
        newItem={newItem}
        setNewItem={setNewItem}
        handleSubmit={handleSubmit}
        inputRef={inputRef}
      />
      <SearchItem
        searchItem={searchItem}
        setSearchItem={setSearchItem}
        inputRef={inputRef}
      />
      <Content
        items={items.filter((item) =>
          item.description.toLowerCase().includes(searchItem.toLowerCase())
        )}
        handleCheck={handleCheck}
        deleteTask={deleteTask}
      />
      <Footer length={items.length} />
    </div>
  );
}

export default App;
