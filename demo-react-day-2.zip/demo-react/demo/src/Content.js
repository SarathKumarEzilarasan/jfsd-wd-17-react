import React, { useState } from "react";
import ItemList from "./ItemList";

const Content = ({ items, handleCheck, deleteTask }) => {
  //   const [name, setName] = useState("john");

  //   function randomName() {
  //     const names = ["john", "peter"];
  //     const i = Math.floor(Math.random() * 2);
  //     return setName(names[i]);
  //   }

  //   const [count, setCount] = useState(99);

  //   function incrementFunc() {
  //     setCount((count) => ++count);
  //     setCount((count) => ++count);
  //     setCount((count) => ++count);
  //   }

  //   function decrementFunc() {
  //     setCount(count - 1);
  //   }

  //   const [name, setName] = useState(() => display());

  //   function display() {
  //     console.log("name");
  //   }

  //   return (
  //     <main>
  //       <p>Logged in by {name}</p>
  //       <button onClick={randomName}>Add</button>
  //       <button onClick={decrementFunc}>-</button>
  //       <span>{count}</span>
  //       <button onClick={incrementFunc}>+</button>
  //     </main>
  //   );

  return (
    <main>
      {items.length ? (
        <ItemList
          items={items}
          handleCheck={handleCheck}
          deleteTask={deleteTask}
        />
      ) : (
        <p style={{ marginTop: "25px" }}>List is Empty</p>
      )}
    </main>
  );
};

export default Content;
