import React, { useRef } from "react";

const AddItem = ({ newItem, setNewItem, handleSubmit, inputRef }) => {
  return (
    <form className="addForm" onSubmit={handleSubmit}>
      <label htmlFor="addItem">Add Item</label>
      <input
        id="addItem"
        type="text"
        placeholder="Add Item"
        required
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
      ></input>
      <button type="submit" onClick={() => inputRef.current.focus()}>
        Add
      </button>
    </form>
  );
};

export default AddItem;
