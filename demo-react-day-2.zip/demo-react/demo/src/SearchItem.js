import React, { useRef } from "react";

const SearchItem = ({ searchItem, setSearchItem, inputRef }) => {
  return (
    <form className="searchForm" onSubmit={(e) => e.preventDefault()}>
      <label htmlFor="search">Search</label>
      <input
        id="search"
        type="text"
        placeholder="Search Items"
        value={searchItem}
        onChange={(e) => setSearchItem(e.target.value)}
        ref={inputRef}
      ></input>
    </form>
  );
};

export default SearchItem;
